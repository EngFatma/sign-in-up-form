<head>
   <meta charset="utf-8" >
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/all.min.css">
    <link href="css/style.css" rel="stylesheet">
</head>
