<!DOCTYPE html>
<html>
<?php  include "header.php" ?>

<body>

    <!-- start nav bar    -->
    <nav class="navbar">
        <div class="nav_img">
            <!-- logo-->
            <img src="imgs/logo.png" width="65" height="60">
        </div>
        <!-- navbar links ul -->
        <ul class="navbar_links">
            <li><a href="#" class="home"> Home </a></li>
            <li><a href="#"> About </a></li>
            <li><a href="#"> Contact </a></li>
            <li><a href="#">portfolio</a></li>
        </ul>
            <div class="dropdown">
                    <button class="dropBtn fa fa-bars fa-2x ">
                    </button>
                    <div class="dropdownContent">
                        <a href="login.php"><i></i>Sign in / up</a>
                        <a href="#">home</a>
                        <a href="#">about</a>
                </div>
            </div>
    </nav>
    <!-- start main    -->
    
<!--    <div id="login_box">
       
        <div class="left_box">
            <h1>Sign Up</h1>
            <input class="signup_inp" type="text" name="username" placeholder="Username">
            <input class="signup_inp" type="email" name="email" placeholder="Email">
            <input  class="signup_inp" type="password" name="password1" placeholder="password">
            <input class="signup_inp" type="password" name="password2" placeholder=" Retype password">
            <input class="signup_btn" type="submit" name="signup_btn" value="Sign up">
            
        </div>
        <div class="right_box">
            <span class="signinwith">sign in with <br/> Social Network </span> 
            <button class="social facebook">Log in with facebook</button>
            <button class="social twitter">Log in with twitter</button>
            <button class="social google">Log in with Google+</button>
        </div>
        
        <div class="or">OR</div>
    </div>
    
    -->
    
    <main>
        <div class="p_aricles">
            <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section> 
            <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section>
            
           
            </section> <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section> 
            <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section>
            
           <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section>
            
           <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section>
            
           <section class="article">
                <h2>article header</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris aliquet malesuada feugiat. Curabitur
                    fermentum bibendum nulla, non dictum ipsum tincidunt non. Quisque convallis pharetra tempor. Donec id pretium
                    leo. 
                    Donec blandit metus ut arcu iaculis iaculis. Cras nec dolor fringilla justo ullamcorper auctor. Aliquam eget
                    pretium velit. Morbi urna justo, pulvinar id lobortis in, aliquet placerat orci.</p>


            </section>
            

        </div>
        <aside>
            <a href="#">item1</a>
            <a href="#">item2</a>



        </aside>



    </main>


    <?php include 'footer.php' ?>
</body>

</html>
